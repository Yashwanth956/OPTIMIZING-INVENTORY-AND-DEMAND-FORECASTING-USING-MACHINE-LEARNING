import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
from sklearn.metrics import mean_squared_error, mean_absolute_error
from tensorflow.keras.callbacks import EarlyStopping
from keras.models import Sequential
from keras.layers import LSTM, Dense
import plotly.graph_objects as go
import plotly.figure_factory as ff
import plotly.express as px
import sqlite3
import hashlib
import time
import chardet
import warnings
warnings.filterwarnings("ignore")

# This must be the first command in your app, and must be set only once
st.set_page_config(page_title="ML Project", layout="wide", page_icon = "D:\ML_Minor2\icon2.png", initial_sidebar_state="expanded")

#Helper function to create a connection to SQLite
def get_connection():
    conn = sqlite3.connect('users_data.db')   # This will create the database file
    return conn

# Helper function to create a users table
def create_users_table():
    conn = get_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
                        username TEXT PRIMARY KEY,
                        password TEXT
                    );''')
    conn.commit()
    conn.close()

# Helper function to hash passwords
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()   

# Save a new user's details into the database
def save_user_to_db(username, password):
    conn = get_connection()
    hashed_password = hash_password(password)
    conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    conn.commit()
    conn.close() 

# Check if a user exists in the database
def is_user_exists(username):
    conn = get_connection()
    cursor = conn.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()
    return user

# Validate login credentials
def validate_login(username, password):
    conn = get_connection()
    hashed_password = hash_password(password)
    cursor = conn.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashed_password))
    user = cursor.fetchone()
    conn.close()
    return user

# Update the user's password in the database
def update_user_password(username, new_password):
    conn = get_connection()
    hashed_password = hash_password(new_password)
    conn.execute("UPDATE users SET password = ? WHERE username = ?", (hashed_password, username))
    conn.commit()
    conn.close()

# Call the function to ensure the users table is created before any operations
create_users_table()

# Session state for login management
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "signed_up" not in st.session_state:
    st.session_state.signed_up = False
if "show_data" not in st.session_state:
    st.session_state.show_data = False
if "reset_password" not in st.session_state:
    st.session_state.reset_password = False

# Color schemes
st.markdown("""
    <style>
        .main { background-color: #f5f5f5; }
        .stButton button { background-color: #4CAF50; color: white; }
        .stTextInput input { background-color: #e8f0fe; }
    </style>
""", unsafe_allow_html=True)

def signup_page():
    st.title("Sign Up")

    with st.form(key='signup_form'):
        username = st.text_input("Enter a new username", "")
        password = st.text_input("Enter a new password", type='password')
        signup_button = st.form_submit_button("Sign Up")

        if signup_button:
            if is_user_exists(username):
                st.error("Username already exists. Please log in.")
            else:
                save_user_to_db(username, password)
                st.session_state.signed_up = True
                st.success("Account created! Redirecting to login...")
                time.sleep(1)
                st.session_state.logged_in = False #Ensure they go to login after signup
                st.rerun()

    st.markdown("<div style='text-align: center; margin-top: 20px;'>", unsafe_allow_html=True)
    st.write("Already have an account?")
    if st.button("Go to Login"):
        st.session_state.signed_up = False  # Toggle the signup page state
        st.rerun()

def reset_password_page():
    st.title("Reset Password")

    with st.form(key='reset_form'):
        username = st.text_input("Enter your username")
        new_password = st.text_input("Enter a new password", type='password')
        confirm_password = st.text_input("Confirm new password", type='password')
        reset_button = st.form_submit_button("Reset Password")

        if reset_button:
            if not is_user_exists(username):
                st.error("Username does not exist.")
            elif new_password != confirm_password:
                st.error("Passwords do not match.")
            else:
                update_user_password(username, new_password)
                st.success("Password has been reset! Redirecting to login...")
                time.sleep(1)
                st.session_state.reset_password = False
                st.rerun()

    st.markdown("<div style='text-align: center; margin-top: 20px;'>", unsafe_allow_html=True)
    st.write("Remembered your password?")
    if st.button("Go to Login"):
        st.session_state.reset_password = False
        st.rerun()

def login_page():
    st.title("Login")
    # Using form to help browsers detect login actions
    with st.form(key='login_form'):
        username = st.text_input("Username")
        password = st.text_input("Password", type='password')
        login_button = st.form_submit_button("Login")

        if login_button:
            user = validate_login(username, password)
            if user:
                st.session_state.logged_in = True
                st.success("Login successful!")
                time.sleep(1)
                st.rerun()  # Force re-render to move to the main app
            else:
                st.error("Incorrect username or password.")

    col1, col2, col3, col4 = st.columns([1, 2, 2, 1])
    with col1:
        st.markdown("<div style='text-align: center; margin-top: 30px;'>", unsafe_allow_html=True)
        st.write("Don't have an account?")
        if st.button("Go to Sign Up"):
            st.session_state.signed_up = True  # Toggle the signup page state
            st.rerun() 

    with col4:
        st.markdown("<div style='text-align: center; margin-top: 30px;'>", unsafe_allow_html=True)
        st.write("Forgot your password?")
        if st.button("Reset Password"):
            st.session_state.reset_password = True
            st.rerun()

       

def toggle_data_visibility():
    st.session_state.show_data = not st.session_state.show_data

def is_date_column(column):
    try:
        pd.to_datetime(column)
        return True
    except (ValueError, TypeError):
        return False

# Main app function
def app():
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = True 

    st.image(r"D:\ML_Minor1\logo2.png", width=100)
    st.header("Welcome to the Web Application")
    st.image(r"D:\ML_Minor1\banner3.jpeg", use_column_width=True)
    st.title("Demand Forecasting & Inventory Optimization📈")

    
    # 2. Provide a default dataset (Holidays)
    st.subheader("Default Datasets (provided by developer)")
    data = {
        'Date': [
            '2024-01-01', '2024-01-13', '2024-01-13', '2024-04-26', 
            '2024-03-08', '2024-04-02', '2024-04-10', '2024-04-17', 
            '2024-05-03', '2024-07-13', '2024-07-17', '2024-08-19', 
            '2024-09-07', '2024-09-08', '2024-10-12', '2024-10-02', 
            '2024-10-31', '2024-11-15', '2024-12-25', '2024-08-15'
        ],
        'Holiday Name': [
        'New Year', 'Lohri', 'Makar Sankranti', 'Republic Day', 
        'Shivratri', 'Ugadi', 'Rama Navami', 'Good Friday', 
        'Ramzan Id/Eid-ul-Fitar', 'Bakr Id/Eid ul-Adha', 'Muharram', 
        'Janmashtami', 'Ganesh Chaturthi', 'Onam', 
        'Mahatma Gandhi Jayanti', 'Navratri', 
        'Diwali', 'Guru Nanak Jayanti', 'Christmas', 
        'Independence Day'
        ],
        'Holiday Impact': [
        'High', 'Medium', 'Low', 'High', 
        'Low', 'Medium', 'Low', 'High', 
        'Low', 'Medium', 'Low', 'High', 
        'High', 'Low', 'High', 'Medium', 
        'Low', 'High', 'Medium', 'Low'
        ],
        'Weather Condition': [
        'Fog', 'Sunny', 'Humid', 'Cloudy', 
        'Sunny', 'Partly Cloudy', 'Clear', 'Clear', 
        'Sunny', 'Sunny', 'Fog', 'Cloudy', 
        'Sunny', 'Sunny', 'Fog', 'Cloudy', 
        'Clear', 'Sunny', 'Sunny', 'Sunny'
        ],
        'Temperature (°C)': [
        17, 25, 23, 19, 
        27, 22, 30, 29, 
        21, 31, 25, 24, 
        28, 29, 22, 21, 
        30, 28, 25, 26
        ],
        'Weather Impact': [
        'Medium', 'Low', 'Medium', 'Low', 
        'Low', 'Low', 'Medium', 'Low', 
        'High', 'Low', 'Medium', 'Medium', 
        'Low', 'Medium', 'Low', 'Medium', 
        'Low', 'Medium', 'Low', 'Medium'
        ],
        'Promotion Name': [
        'Winter Sale', 'No Promotion', 'No Promotion', 'Republic Day Offer', 
        'No Promotion', 'Holi Festival Discount', 'No Promotion', 'No Promotion', 
        'Eid Celebration Discount', 'Independence Day Sale', 'No Promotion', 
        'No Promotion', 'Ganesh Chaturthi Promo', 'No Promotion', 
        'Onam Special Offer', 'No Promotion', 'Navratri Special', 
        'Diwali Discount', 'No Promotion', 'Christmas Bonanza'
        ],
        'Discount Percentage (%)': [
        10, 0, 0, 15, 
        0, 30, 0, 0, 
        35, 40, 0, 0, 
        25, 0, 40, 25, 
        50, 0, 50, 0
        ],
        'Promotion Impact': [
        'Medium', 'None', 'None', 'Medium', 
        'None', 'Medium', 'None', 'None', 
        'High', 'High', 'None', 
        'None', 'High', 'None', 
        'Medium', 'Medium', 'Very High', 
        'None', 'Very High', 'None'
        ],
        'Economical Indicator': [
            'High',    # New Year
            'Medium',  # Lohri
            'Low',     # Makar Sankranti
            'High',    # Republic Day
            'Low',     # Shivratri
            'Medium',  # Ugadi
            'Low',     # Rama Navami
            'High',    # Good Friday
            'High',    # Eid-ul-Fitr
            'Medium',  # Bakr Id
            'Low',     # Muharram
            'Medium',  # Janmashtami
            'High',    # Ganesh Chaturthi
            'Medium',  # Onam
            'Low',     # Mahatma Gandhi Jayanti
            'Medium',  # Navratri
            'High',    # Diwali
            'Medium',  # Guru Nanak Jayanti
            'High',    # Christmas
            'High'    # Independence Day
        ]
    }
    external_factors_df = pd.DataFrame(data)
    external_factors_df['Date'] = pd.to_datetime(external_factors_df['Date'])

    customer_data = {
    'Customer ID': [1, 2, 3, 4, 5],
    'Customer Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Age': [28, 34, 22, 45, 30],
    'Gender': ['Female', 'Male', 'Male', 'Male', 'Female'],
    'Location': ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'],
    'Purchase History': ['Electronics', 'Clothing', 'Books', 'Grocery', 'Sports'],
    'Preferred Holidays': [
        'New Year', 'Christmas', 'Diwali', 
        'Independence Day', 'Lohri'
    ],
    'Spending Habit': ['Medium', 'High', 'Low', 'Medium', 'High']
    }
    customer_info_df = pd.DataFrame(customer_data)

    button_label = "Hide datasets" if st.session_state.show_data else "Show datasets"

    if st.button("Show datasets" if not st.session_state.show_data else "Hide datasets", on_click=toggle_data_visibility):
        pass
    st.markdown("&nbsp;"*5, unsafe_allow_html=True)

    if st.session_state.show_data:
        col1, col2 = st.columns(2)
    
        with col1:
            st.write("### External Factors Dataset")
            st.dataframe(external_factors_df)

        with col2:
            st.write("### Customer Info Dataset")
            st.write("Edit the Customer Info dataset as needed and use it for predictions.")
            edited_customer_info_df = st.data_editor(customer_info_df, 
                                           num_rows="dynamic", 
                                           use_container_width=True)

        st.markdown("<br>" * 2, unsafe_allow_html=True)
    
    # User-side data upload (shopkeepers, retailers, etc.)
    st.subheader("Upload Sales Data (Max 3 CSV/XLSX files)")
    uploaded_files = st.file_uploader("Upload datasets (CSV/XLSX)", type=["csv", "xlsx"], accept_multiple_files=True)
    st.markdown("<p style='font-family: Arial; font-size: 18px; color: tomato; text-align: center'>[NOTE]: The  uploaded  dataset/s  must  contain  'Sales  related column'  and  'Date  related  column'</p>", unsafe_allow_html=True)
    
    if uploaded_files:
        if len(uploaded_files) > 5:
            st.error("You can upload a maximum of 5 files only.")
        else:
            datasets = {}
            total_size = 0
            for uploaded_file in uploaded_files:
                if uploaded_file.size > 0:
                    try:
                        if uploaded_file.name.endswith('.csv'):
                            raw_data = uploaded_file.read(10000)
                            encoding = chardet.detect(raw_data)['encoding']
                            uploaded_file.seek(0)  # Reset file pointer
                            total_size += uploaded_file.size
                            datasets[uploaded_file.name] = pd.read_csv(uploaded_file)
                        elif uploaded_file.name.endswith('.xlsx'):
                            datasets[uploaded_file.name] = pd.read_excel(uploaded_file)
                    except pd.errors.EmptyDataError:
                        st.error(f"{uploaded_file.name} is empty or has no columns to parse.")
                    except UnicodeDecodeError:
                        st.warning(f"Failed to read {uploaded_file.name} with default encoding. Trying with ISO-8859-1.")
                        datasets[uploaded_file.name] = pd.read_csv(uploaded_file, encoding='ISO-8859-1')
                    except Exception as e:
                        st.error(f"Error loading {uploaded_file.name}: {e}")
                else:
                    st.error(f"{uploaded_file.name} is an empty file.")                   

            # Displaying data preview
            for name, data in datasets.items():
                st.write(f"**{name}**")
                st.write("Here is a preview of your dataset:")
                st.write(data.head())

            # Evaluate data size
            total_size = sum([df.memory_usage().sum() for df in datasets.values()])
            st.write(f"**Total size of data: {total_size / (1024 ** 2):.2f} MB**")

            # Handle session state for evaluation and model selection
            if "evaluated" not in st.session_state:
                st.session_state.evaluated = False
            
            # Provide an evaluation button
            evaluate_button = st.button("Evaluate Data")
            st.markdown("<br>" * 1, unsafe_allow_html=True)

            if evaluate_button or st.session_state.evaluated:
                st.session_state.evaluated = True
                st.write("Performing Inventory Optimization and Sales Prediction...")
                        
                # 4. Inventory Optimization
                st.subheader("Inventory Optimization")
                safety_stock_level = st.slider("Select Safety Stock Level", min_value=100, max_value=1000, value=300)

                col1, col2, col3 = st.columns(3)
                datasets_list = list(datasets.items())
                for index, (name, dataset) in enumerate(datasets_list):
                    current_col = col1 if index == 0 else col2 if index == 1 else col3
                    with current_col:
                        possible_sales_columns = ['Sales', 'sales', 'SalesQuantity', 'salesquantity', 'QuantitySold', 'quantitysold']

                        sales_column = None
                        for col in possible_sales_columns:
                            if col in dataset.columns:
                                sales_column = col
                                break

                        if sales_column:
                            dataset.rename(columns={sales_column: 'Sales'}, inplace=True)
                            dataset['Reorder Level'] = np.where(dataset['Sales'] < safety_stock_level, "Reorder", "Sufficient")

                            st.write(f"Reorder Level for {name}:")
                            st.write(dataset[['Sales', 'Reorder Level']].head())
                            st.write(f"Safety Stock Level selected: {safety_stock_level}")
                        else:
                            st.warning(f"Sales column not found in the dataset {name}. Please upload a dataset that contains sales column.")
                            
                            
                        # Ensure dataset has been loaded
                        if len(datasets) > 0:
                            possible_date_columns = [
                            'date', 'datetime', 'timestamp', 'time', 
                            'order date', 'Order Date', 'Order_Date', 
                            'purchase date', 'Purchase Date', 
                            'sale date', 'Sale Date', 
                            'transaction date', 'Transaction Date', 
                            'ship date', 'Ship Date', 
                            'invoice date', 'Invoice Date', 
                            'payment date', 'Payment Date', 
                            'dispatch date', 'Dispatch Date', 
                            'delivery date', 'Delivery Date', 
                            'sale date', 'Sale Date', 'date of sale', 
                            'sold date', 'Sold Date', 
                            'event date', 'Event Date', 
                            'start date', 'Start Date', 
                            'end date', 'End Date', 
                            'close date', 'Close Date',
                            'salesdate', 'SalesDate' 
                            'registration date', 'Registration Date', 
                            'signup date', 'Signup Date', 
                            'login date', 'Login Date', 
                            'last purchase date', 'Last Purchase Date', 
                            'last login date', 'Last Login Date', 
                            'fiscal year', 'Fiscal Year', 
                            'reporting date', 'Reporting Date', 
                            'report date', 'Report Date', 
                            'due date', 'Due Date', 
                            'last updated', 'Last Updated', 
                            'expiry date', 'Expiry Date', 
                            'effective date', 'Effective Date', 
                            'date of birth', 'Date of Birth'
                            ]
                            normalized_possible_dates = [col.lower().replace(' ', '_') for col in possible_date_columns]

                            # Check if a column related to Date exists
                            date_column = None
                            for col in dataset.columns:
                                normalized_col = col.lower().replace(' ', '_')
                                if normalized_col in normalized_possible_dates:
                                    date_column = col  # Store the actual column name from the dataset
                                    break 
                        
                            if date_column is None:
                                st.error(f"No Date-related column found in the {name} dataset. Upload valid dataset.")
                                continue
                            else:                                # Convert the identified date column to datetime format with dayfirst=True
                                dataset[date_column] = pd.to_datetime(dataset[date_column], dayfirst=True, errors='coerce')
                                dataset['DayOfYear'] = dataset[date_column].dt.dayofyear

                                with current_col:
                                    st.subheader(f"Date Processing for {name}")
                                    st.success(f"Successfully processed the dataset with {date_column} as the date-related column.")
                                    st.write(dataset[['DayOfYear', date_column]].head())
                                    st.markdown("<br>" * 1, unsafe_allow_html=True)
                                # Sales Prediction
                                if 'Sales' in dataset.columns:
                                    X = dataset[['DayOfYear']]
                                    y = dataset['Sales']
                                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42) # Optional: Debugging check

                                    with current_col:
                                        name = f"Dataset {index + 1}"
                                        st.subheader(f"Sales prediction for {name}")
                                        
                                        selected_model = st.selectbox(
                                            f"Choose a forecasting model for {name}:", ["None", "Linear Regression", "Random Forest", "ARIMA", "LSTM (Long-Short-Term-Memory)"],
                                            key = f"model_{index}"
                                        )

                                        if selected_model != "None":
                                            model = None
                                            y_pred = None
                                            y_pred_rescaled = None
                                            y_test_rescaled = y_test    

                                            # Linear regression model
                                            if selected_model == "Linear Regression":
                                                model = LinearRegression()
                                                model.fit(X_train, y_train)
                                                y_pred = model.predict(X_test)
                                                y_pred_rescaled = y_pred  

                                                # Linear Regression specific recommendation
                                                st.subheader("Sales Recommendations")
                                                st.write(f"Model: {selected_model}")
                                                st.write("""
                                                    Recommendation:  Linear regression suggests that the sales trend is relatively stable. 
                                                    Based on this model, consider using previous sales data to project inventory needs 
                                                    for the future. Adjust inventory based on seasonal sales patterns.
                                                """)

                                            elif selected_model == "Random Forest":
                                                model = RandomForestRegressor(n_estimators=100, random_state=42)
                                                model.fit(X_train, y_train)
                                                y_pred = model.predict(X_test)
                                                y_pred_rescaled = y_pred 

                                                st.subheader("Sales Recommendations")
                                                st.write(f"Model: {selected_model}")
                                                st.write("""
                                                    Recommendation:  The Random Forest model is sensitive to fluctuations in sales, 
                                                    which means it captures potential surges in demand or downturns. Based on this model, 
                                                    you might want to keep a buffer stock to accommodate unexpected sales increases. 
                                                    Consider promotions during predicted high-demand periods to maximize revenue.
                                                """)

                                            elif selected_model == "ARIMA":
                                                y_train_series = dataset.set_index(date_column)['Sales']  # Set the date column as index for time series
                                                arima_model = ARIMA(y_train_series, order=(5, 1, 0))
                                                model = arima_model.fit()  # Fitting the model
                                                y_pred = model.forecast(steps=len(X_test)) 
                                                y_pred_rescaled = y_pred  # Assuming ARIMA predicts in the original scale of sales

                                                st.subheader("Sales Recommendations")
                                                st.write(f"Model: {selected_model}")
                                                st.write("""
                                                    Recommendation:  ARIMA detects seasonal trends and cyclical patterns in your sales data. 
                                                    If the forecast predicts sales growth in certain months, consider ramping up production or 
                                                    inventory. Conversely, if sales are expected to dip, adjust marketing and sales strategies 
                                                    to counteract the decline.
                                                """)
                            
                                            elif selected_model == "LSTM (Long-Short-Term-Memory)":
                                                # LSTM model for time series forecasting
                                                scaler = MinMaxScaler(feature_range=(0, 1))
                                                scaled_data = scaler.fit_transform(data[['Sales']])

                                                time_steps = 10  # Adjust as needed
                                                X, y = [], []

                                                for i in range(len(scaled_data) - time_steps):
                                                    X.append(scaled_data[i:i+time_steps, 0])
                                                    y.append(scaled_data[i+time_steps, 0])

                                                X, y = np.array(X), np.array(y)

                                                # Reshape X for LSTM (samples, time_steps, features)
                                                X = X.reshape((X.shape[0], X.shape[1], 1))

                                                # Split data
                                                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

                                                # Build LSTM model
                                                model = Sequential()
                                                model.add(LSTM(20, return_sequences=False, input_shape=(time_steps, 1)))
                                                model.add(Dense(1))

                                                # Compile model
                                                model.compile(optimizer='adam', loss='mean_squared_error')

                                                # Train the model
                                                model.fit(X_train, y_train, epochs=5, batch_size=32, validation_data=(X_test, y_test))

                                                # Perform predictions for the test data
                                                y_pred = model.predict(X_test)

                                                # Rescale the predictions back to the original scale
                                                y_pred_rescaled = scaler.inverse_transform(y_pred)
                                                y_test_rescaled = scaler.inverse_transform(y_test.reshape(-1, 1))

                                                # Early stopping to prevent overtraining
                                                early_stop = EarlyStopping(monitor='loss', patience=2, restore_best_weights=True)

                                                # LSTM specific recommendation
                                                st.subheader("Sales Recommendations")
                                                st.write(f"Model: {selected_model}")
                                                st.write("""
                                                        Recommendation:  LSTM is great for capturing longer-term dependencies in your sales data. 
                                                        This model can detect long-range patterns, such as yearly seasonality. Based on this, 
                                                        it's recommended to optimize both short-term and long-term sales strategies. 
                                                        For example, if sales are expected to increase over several months, consider promotional 
                                                        events or product launches.
                                                """)
                                    
                                            if y_pred_rescaled is not None and y_test_rescaled is not None:
                                                # Flatten arrays for plotting
                                                y_test_rescaled_flat = np.array(y_test_rescaled).flatten()
                                                y_pred_rescaled_flat = np.array(y_pred_rescaled).flatten()

                                                # Visualize prediction
                                                fig = go.Figure(data=go.Scatter(x=y_test_rescaled_flat, y=y_pred_rescaled_flat, mode='markers'))
                                                fig.update_layout(
                                                    title="Predicted vs Actual Sales",
                                                    xaxis_title="Actual Sales",
                                                    yaxis_title="Predicted Sales"
                                                )
                                                st.plotly_chart(fig)

                                                # 8. Model Suggestions for large datasets
                                                total_size = dataset.memory_usage(deep=True).sum()
                                                if total_size > 50 * (1024 ** 2):  # if dataset is larger than 50MB
                                                    st.warning("Your dataset is large. For better performance, consider using models like LSTM or XGBoost.")
                                                    continue

                                            st.markdown("<br>" * 1, unsafe_allow_html=True)
                                            st.subheader("Future Sales Forecast")
                                            forecast_days = st.slider(f"Select days for future forecast for {name}", 1, 30, 7, key = f"forecast_days_{index}")
                                            # Future Sales Forecast for LSTM
                                            if selected_model == "LSTM (Long-Short-Term-Memory)":
                                                # Prepare for future prediction using the last available time window from the dataset
                                                last_sequence = scaled_data[-time_steps:]  # Using the last `time_steps` rows

                                                future_predictions = []
                                                for _ in range(forecast_days):
                                                    last_sequence_reshaped = last_sequence.reshape((1, time_steps, 1))
        
                                                    # Predict the next value
                                                    next_prediction = model.predict(last_sequence_reshaped)[0, 0]
                                                    future_predictions.append(next_prediction)
                                                    last_sequence = np.roll(last_sequence, -1)
                                                    last_sequence[-1] = next_prediction

                                                # Rescale the predictions back to the original scale
                                                future_predictions_rescaled = scaler.inverse_transform(np.array(future_predictions).reshape(-1, 1))
                                                # Generate future dates
                                                future_dates = pd.date_range(start=dataset[date_column].max(), periods=forecast_days + 1, freq='D')[1:]

                                                # Create a DataFrame with the forecasted sales
                                                forecast_df = pd.DataFrame({'Date': future_dates, 'Forecasted Sales': future_predictions_rescaled.flatten()})

                                                st.write("Forecasted Sales for the next few days:")
                                                st.write(forecast_df)

                                            # Handle forecasting for Linear Regression, Random Forest, and ARIMA models
                                            elif selected_model in ["Linear Regression", "Random Forest", "ARIMA"]:
                                                future_X = pd.DataFrame({
                                                    'DayOfYear': [(X['DayOfYear'].max() + i) % 365 for i in range(forecast_days)]
                                                })

                                                if selected_model == "ARIMA":
                                                    future_pred = model.forecast(steps=forecast_days)

                                                else:  # Linear Regression or Random Forest
                                                    future_pred = model.predict(future_X)

                                                # Generate future dates
                                                future_dates = pd.date_range(start=dataset[date_column].max(), periods=forecast_days + 1, freq='D')[1:]

                                                date_column = col  
                                                dataset[date_column] = pd.to_datetime(dataset[date_column])  # Ensure it's in datetime format
                                                future_dates = pd.date_range(start=dataset[date_column].max(), periods=forecast_days + 1, freq='D')[1:]

                                                # Create a DataFrame with the forecasted sales
                                                forecast_df = pd.DataFrame({'Date': future_dates, 'Forecasted Sales': future_pred})

                                                st.write("Forecasted Sales for the next few days:")
                                                st.write(forecast_df)
                                                st.markdown("<br>" * 1, unsafe_allow_html=True)

                                            st.download_button(f"Download Forecast Data", forecast_df.to_csv(index=False), file_name="forecasted_sales_{name}.csv", key=f"download_{name}_{index}")
                                else:
                                    st.error("Please add Sales column in your dataset for performing sales predictions.")
                                    continue
                        else: 
                            print("No datasets uploaded!")

def show_about():
    st.title("About This App")
    st.write("""
    **Sales Prediction Models**:
        
    In this application, we use a variety of machine learning models for sales predictions. Here's a breakdown of the models:

    1. **Linear Regression**:
       - Assumes a linear relationship between features and sales.
        
    2. **Random Forest**:
       - A robust ensemble model that aggregates results from multiple decision trees.
        
    3. **ARIMA (AutoRegressive Integrated Moving Average)**:
       - A time series model for detecting trends and seasonality.

    4. **LSTM (Long Short-Term Memory)**:
       - Captures long-term dependencies in time series data.
       
    **Future Improvements**:
    - We're working on incorporating external factors like marketing campaigns and holidays.
    - New models like **XGBoost** and **Prophet** are in development for more accurate predictions.
    """)

def show_ask_question():
    st.title("Ask a Question")
    question = st.text_area("Ask your question here:")
    if st.button("Submit Question"):
        st.success("Your question has been submitted. We'll get back to you soon!")

def show_feedback():
    st.title("We Value Your Feedback")
    st.subheader("Rate Your Experience")
    st.write("How would you rate your experience with our Sales Predictions App?")
    

    if 'rating' not in st.session_state:
        st.session_state.rating = 0

    col1, col2, col3, col4, col5 = st.columns(5)
    star_button_css = """
        <style>
            /* Styling the star buttons based on the key */
            div[data-testid="star1"] button {
                background-color: #C0C0C0; /* Silver color */
                font-size: 2em;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                padding: 10px;
            }
            div[data-testid="star1"] button:hover {
                background-color: #A9A9A9; /* Darker silver on hover */
            }

            div[data-testid="star2"] button {
                background-color: #C0C0C0;
                font-size: 2em;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                padding: 10px;
            }
            div[data-testid="star2"] button:hover {
                background-color: #A9A9A9;
            }

            div[data-testid="star3"] button {
                background-color: #C0C0C0;
                font-size: 2em;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                padding: 10px;
            }
            div[data-testid="star3"] button:hover {
                background-color: #A9A9A9;
            }

            div[data-testid="star4"] button {
                background-color: #C0C0C0;
                font-size: 2em;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                padding: 10px;
            }
            div[data-testid="star4"] button:hover {
                background-color: #A9A9A9;
            }

            div[data-testid="star5"] button {
                background-color: #C0C0C0;
                font-size: 2em;
                border: none;
                cursor: pointer;
                border-radius: 5px;
                padding: 10px;
            }
            div[data-testid="star5"] button:hover {
                background-color: #A9A9A9;
            }
        </style>
    """
    st.markdown(star_button_css, unsafe_allow_html=True)
    with col1:
        if st.button('⭐', key='star1'):
            st.session_state.rating = 1
    with col2:
        if st.button('⭐', key='star2'):
            st.session_state.rating = 2
    with col3:
        if st.button('⭐', key='star3'):
            st.session_state.rating = 3
    with col4:
        if st.button('⭐', key='star4'):
            st.session_state.rating = 4
    with col5:
        if st.button('⭐', key='star5'):
            st.session_state.rating = 5

    if st.session_state.rating > 0:
        st.write(f"You selected: {'⭐' * st.session_state.rating}")

    st.subheader("Leave Your Comments")
    feedback = st.text_area("Please provide your feedback regarding the app:")
    if st.button("Submit Feedback"):
        if feedback or st.session_state.rating:
            st.success(f"Thank you for your feedback! You rated the app {st.session_state.rating} stars.😊")
        else:
            st.error("Please provide either a rating or some written feedback.")
    
    st.write("Your feedback helps us improve the app and deliver a better experience for you in the future!")

def logout():
    st.title("Logout")
    st.write("Thank you for visiting our Sales Prediction Platform. We hope you found the insights and recommendations helpful! 😀")
    st.markdown("<br>" * 1, unsafe_allow_html=True)
    if st.session_state.get('logged_in', False):
        st.subheader("Ready to Log Out?")
        st.write("""
            If you have completed your tasks and would like to log out, click the button below. 
            We appreciate your time and look forward to seeing you again soon!✨
        """)

        if st.button("Confirm Logout", key="logout"):
            st.session_state.logged_in = False  
            st.success("You have been logged out successfully.")
            st.balloons()  # Celebrate their visit with balloons!
            st.write("Redirecting you back to the login page...")
            time.sleep(1)
            st.rerun()
    else:
        st.info("You are already logged out.")

# Main routing logic based on session state
def main():
    if not st.session_state.logged_in:
        if st.session_state.signed_up:
            signup_page()  # Show the signup page
        elif st.session_state.reset_password:
            reset_password_page()
        else:
            login_page()  # Show the login page
    else:
        st.sidebar.title("Dashboard")
        st.sidebar.markdown("---")
        page = st.sidebar.selectbox("Choose a section", ["App", "About", "Ask a Question", "Feedback", "Logout"])

        if page == "App":
            app()
        elif page == "About":
            show_about()
        elif page == "Ask a Question":
            show_ask_question()
        elif page == "Feedback":
            show_feedback()
        elif page == "Logout":
            logout()

# Call the main function to route the app
if __name__ == "__main__":
    main()